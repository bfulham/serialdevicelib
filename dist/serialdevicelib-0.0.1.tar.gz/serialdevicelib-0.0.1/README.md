Work in progress

SERIAL / ETHERNET INTERFACE COMMUNICATION PROTOCOL SPECIFICATION (SICP V2.10) For Philips Professional Displays

TODO:
    - Finish data file based on documentation (tedious af)
    -